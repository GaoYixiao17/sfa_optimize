/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file checker_adapter_lightning_indexer_v2.h
 * \brief Adapts tiling context inputs and outputs to the common checker data model.
 */

#ifndef CHECKER_ADAPTER_LIGHTNING_INDEXER_V2_H
#define CHECKER_ADAPTER_LIGHTNING_INDEXER_V2_H

#include "checker_context_lightning_indexer_v2.h"
#include "exe_graph/runtime/tiling_context.h"

namespace optiling {
namespace lightning_indexer_v2_checker {

CheckerTensor MakeRequiredTensor(const gert::TilingContext *context, uint32_t index);
CheckerTensor MakeOptionalTensor(const gert::TilingContext *context, uint32_t index);
CheckerTensor MakeOutputTensor(const gert::TilingContext *context, uint32_t index);
void PopulateDerivedInfo(LightningIndexerV2CheckerInfo &info);

} // namespace lightning_indexer_v2_checker
} // namespace optiling

#endif // CHECKER_ADAPTER_LIGHTNING_INDEXER_V2_H
